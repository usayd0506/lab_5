#include <stdio.h>

int main() {
    int num, sum = 0;

    printf("Enter a number: ");
    scanf("%d", &num);

    while (num > 9) {
        while (num > 0) {
            sum += num % 10;
            num /= 10;
        }

        num = sum;
        sum = 0;
    }

    printf("The sum of digits until a single digit is: %d\n", num);

    return 0;
}

