#include <stdio.h>

int main() {
    char ch, encrypted, decrypted;
    int key;

    printf("Enter a character: ");
    scanf("%c", &ch);

    printf("Enter the key: ");
    scanf("%d", &key);
    encrypted = ch ^ key;

    printf("Encrypted character: %c\n", encrypted);
    decrypted = encrypted ^ key;

    printf("Decrypted character: %c\n", decrypted);

    return 0;
}