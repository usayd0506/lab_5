#include <stdio.h>

int main() {
    int age, income, credit;

    printf("Enter your age: ");
    scanf("%d", &age);

    printf("Enter your  income: ");
    scanf("%d", &income);

    printf("Enter your credit : ");
    scanf("%d", &credit);

    if ((age >= 25 && age <= 60) && income >= 30000 && credit >= 700) {
        printf("You are eligible for a loan.\n");
    } else {
        printf("You are not eligible for a loan.\n");
    }

    return 0;
}