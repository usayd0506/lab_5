#include <stdio.h>
int main (){
    int age;
    printf("Enter your age");
    scanf("%d",&age);
    if (age<=12){
        printf("you are a child");
    }
    else if(age<=18){
        printf("you are a teenager");
        
    }
    else if (age<=62){
        printf("you are an adult");

    }
    else {
        printf("you are  senior");
    }
    return 0;
}