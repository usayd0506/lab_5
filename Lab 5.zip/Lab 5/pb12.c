#include <stdio.h>

int main() {
    float attendance, assignment, score, final_grade;

    printf("Enter attendance percentage: ");
    scanf("%f", &attendance);

    printf("Enter average assignment score: ");
    scanf("%f", &assignment);

    printf("Enter exam score: ");
    scanf("%f", &score);

    
    if (attendance >= 90 && assignment >= 80 && score >= 80) {
        final_grade = 0.2 * attendance + 0.3 * assignment + 0.5 * score;
    } else if (attendance >= 80 && assignment >= 70 && score >= 70) {
        final_grade = 0.25 * attendance + 0.3 * assignment + 0.45 * score;
    } else if (attendance >= 70 && assignment >= 60 && score >= 60) {
        final_grade = 0.2 * attendance + 0.35 * assignment + 0.45 * score;
    } else {
        final_grade = 0;
    }

    
    printf("Final grade: %.2f\n", final_grade);

    return 0;
}