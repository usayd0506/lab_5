#include <stdio.h>

int main() {
    int number;
    printf("Enter a number: ");
    scanf("%d", &number);
    printf("The number is %s.\n", (number > 0) ? "positive" : (number < 0) ? "negative" : "zero");
    return 0;
}

